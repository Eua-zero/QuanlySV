﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace De01
{
    public partial class frmSinhViebn : Form
    {
        public frmSinhViebn()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                SinhVienDBContext context = new SinhVienDBContext();
                List<Lop> listlopds = context.Lops.ToList();
                List<SinhVien> listsinhVien = context.SinhViens.ToList();
                FillLopdCombobox(listlopds);
                BindGrid(listsinhVien);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void FillLopdCombobox(List<Lop> listLopds)
        {
            this.cmbLop.DataSource = listLopds;
            this.cmbLop.DisplayMember = "TenLop";
            this.cmbLop.ValueMember = "MaLop";
        }
        private void BindGrid(List<SinhVien> listSinhVien)
        {
            dgvStudent.Rows.Clear();
            dgvStudent.Rows.Clear();
            using (var context = new SinhVienDBContext())
            {
                var query = from sv in context.SinhViens
                            join lop in context.Lops on sv.MaLop equals lop.MaLop
                            select new
                            {
                                sv.MaSV,
                                sv.HoTenSV,
                                sv.NgaySinh,
                                lop.TenLop
                            };

                foreach (var item in query.ToList())
                {
                    int index = dgvStudent.Rows.Add();
                    dgvStudent.Rows[index].Cells[0].Value = item.MaSV;
                    dgvStudent.Rows[index].Cells[1].Value = item.HoTenSV;
                    dgvStudent.Rows[index].Cells[2].Value = item.NgaySinh.ToShortDateString();
                    dgvStudent.Rows[index].Cells[3].Value = item.TenLop;
                }
            }
        }

        private void dgvStudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvStudent.Rows[e.RowIndex];
                txtMaSV.Text = row.Cells["MaSV"].Value?.ToString();
                txtHoTen.Text = row.Cells["HoTen"].Value?.ToString();
                dtpNgaySinh.Value = Convert.ToDateTime(row.Cells["NgaySinh"].Value);
                cmbLop.Text = row.Cells["Lop"].Value?.ToString();
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                SinhVienDBContext context = new SinhVienDBContext();
                SinhVien newSinhVien = new SinhVien
                {
                    MaSV = txtMaSV.Text,
                    HoTenSV = txtHoTen.Text,
                    NgaySinh = dtpNgaySinh.Value,
                    MaLop = cmbLop.SelectedValue.ToString()
                };
                context.SinhViens.Add(newSinhVien);
                context.SaveChanges();
                RefreshGrid();
                MessageBox.Show("Thêm sinh viên thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                SinhVienDBContext context = new SinhVienDBContext();
                string MaSV = txtMaSV.Text;
                SinhVien sinhVien = context.SinhViens.FirstOrDefault(s => s.MaSV == MaSV);

                if (sinhVien != null)
                {
                    sinhVien.HoTenSV = txtHoTen.Text;
                    sinhVien.MaLop = cmbLop.SelectedValue.ToString();
                    sinhVien.NgaySinh = dtpNgaySinh.Value;
                    context.SaveChanges();
                    RefreshGrid();
                    MessageBox.Show("Cập nhật thông tin sinh viên thành công!");
                }
                else
                {
                    MessageBox.Show("Không tìm thấy sinh viên!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                SinhVienDBContext context = new SinhVienDBContext();
                string MaSV = txtMaSV.Text;
                SinhVien sinhvien = context.SinhViens.FirstOrDefault(s => s.MaSV == MaSV);

                if (sinhvien != null)
                {
                    context.SinhViens.Remove(sinhvien);
                    context.SaveChanges();
                    RefreshGrid();
                    MessageBox.Show("Xóa sinh viên thành công!");
                }
                else
                {
                    MessageBox.Show("Không tìm thấy sinh viên!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void RefreshGrid()
        {
            SinhVienDBContext context = new SinhVienDBContext();
            List<SinhVien> listSinhVien = context.SinhViens.ToList();
            BindGrid(listSinhVien);
            ClearInputFields();
        }
        private void ClearInputFields()
        {
            txtMaSV.Clear();
            txtHoTen.Clear();
            dtpNgaySinh.Value = DateTime.Now;
            cmbLop.SelectedIndex = -1;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (var context = new SinhVienDBContext())
            {

            }
        }
        
        private void btnThoat_Click(object sender, EventArgs e)
        {
             this.Close();
        }
    }
}
